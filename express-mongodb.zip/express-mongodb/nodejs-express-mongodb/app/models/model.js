module.exports = mongoose => {
    const Data = mongoose.model(
      "ColDataBOD",
      mongoose.Schema(
        {
          nama: String,
          gender: String
        },
        { timestamps: true }
      )
    );
    return Data;
  };