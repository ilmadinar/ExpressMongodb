module.exports = app => {
    const Datas = require("../controllers/controller.js");
    var router = require("express").Router();
    // Create a new Data
    router.post("/", Datas.create);
    // Retrieve all Datas
    router.get("/", Datas.findAll);
    // Retrieve all published Datas
    router.get("/published", Datas.findAllPublished);
    // Retrieve a single Data with id
    router.get("/:id", Datas.findOne);
    // Update a Data with id
    router.put("/:id", Datas.update);
    // Delete a Data with id
    router.delete("/:id", Datas.delete);
    // Create a new Data
    router.delete("/", Datas.deleteAll);
    app.use('/api/Datas', router);
  };